//Bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro / 2;

//Raquete
let xRaquete = 5;
let yRaquete = 150;
let rComprimento = 10;
let rAltura = 90;

let colidiu = false;

//variáveis do oponente
let xOponente = 585;
let yOponente = 150;
let velocidadeYOp  ;

//Velocidade Bolinha
let velocidadeXBolinha = 5;
let velocidadeYBolinha = 5;

//Placar
let meusPontos = 0;
let pontosOponente = 0;

//Sons
let raquetada;
let ponto;
let trilha;

//Dificuldade
let chanceDeErrar = 0;


function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  reconheceBorda();
  minhaRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  colisaoMinhaRaquete();
  minhaRaquete(xOponente, yOponente);
  movimentaRaqueteOp();
  colisaoRaqueteOp();
  placar();
  marcaPontos();
  bolinhaNaoFicaPresa();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
}

function movimentaBolinha(){
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha;
}

function reconheceBorda(){
  if (xBolinha + raio > width || 
             xBolinha - raio <0 ){
    velocidadeXBolinha *= -1;
                        }
  if (yBolinha + raio > height || 
           yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
    }
}

function minhaRaquete(x,y){
  rect(x, y, rComprimento, rAltura);
}

function movimentaMinhaRaquete(){
  if (keyIsDown(UP_ARROW)){
    yRaquete -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete += 10;}
}
function colisaoMinhaRaquete() {
  if (xBolinha - raio < xRaquete + rComprimento  && yBolinha - raio < yRaquete + rAltura && yBolinha + raio > yRaquete ) {
 velocidadeXBolinha *= -1;
  raquetada.play();
     }
}

function movimentaRaqueteOp() {
  velocidadeYOp = yBolinha - yOponente - rComprimento / 2 -30;
  yOponente += velocidadeYOp + chanceDeErrar;
  calculaChanceDeErrar();
  }
    
function colisaoRaqueteOp(){
  colidiu = 
  collideRectCircle(xOponente, yOponente, rComprimento, rAltura, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
 }

function placar(){
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0)) 
  rect(150,10,40,20);
  fill(255);
  text(meusPontos, 170, 26);
   fill(color(255, 140, 0)) 
  rect(450,10,40,20);
  fill(255);
  text(pontosOponente, 470, 26);
}

function marcaPontos(){
  if(xBolinha + raio > 599){
    meusPontos += 1;
    ponto.play();
  }
   if(xBolinha - raio < 0){
    pontosOponente += 1;
    ponto.play();
   }
}

function calculaChanceDeErrar() {
  if (pontosOponente >= meusPontos + 7) {
    chanceDeErrar += 1
    if (chanceDeErrar >= 39){
    chanceDeErrar = 40
    }
  } else {
    chanceDeErrar -= 1
    if (chanceDeErrar <= 35){
    chanceDeErrar = 35
    }
  }
}
 
function bolinhaNaoFicaPresa(){
    if (xBolinha - raio < 0){
    xBolinha = 23
    }
    if (xBolinha + raio > 600){
    xBolinha = 577
    }
}
